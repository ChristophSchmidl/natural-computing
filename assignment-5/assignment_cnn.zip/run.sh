#!/bin/bash
source .env/bin/activate 
ipython notebook
deactivate
