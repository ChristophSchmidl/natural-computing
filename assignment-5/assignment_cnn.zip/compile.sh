#!/bin/bash
source .env/bin/activate 
cd nc17nn
python setup.py build_ext --inplace
deactivate
